# 20260309 Writer Adapter Upgrade

## Purpose
Execute `PLANv4.md` fallback F1b after F1a ended at `move_to_f1b`: keep the bigger writer scaffold fixed, freeze the base writer, and test whether a tiny writer-side micro-LoRA on writer projection layers can create geometry signal without reopening receiver-side PEFT.

## Context
- Macro authority remains `PLAN.md`.
- Narrow authority is `PLANv4.md` Section 18.1 fallback F1b.
- W0 proved the writer-direct path is wired but only reached `plumbing_only`.
- F1a increased writer capacity and conditioning depth, then stopped at `move_to_f1b`; usefulness stayed flat and geometry regressed badly on `top1_top2_ratio`.
- `PLANv4` explicitly allows only a small writer-side adapter here, not a broader receiver fallback.

## Plan of Work
1. Add a tiny writer-only micro-LoRA path on addressable `WriterWeaverHead` projection layers.
2. Keep the rest of the direct bridge fixed: same frozen reasoner, same projector, same Tier-1 slices, same usefulness and anti-common-mode losses.
3. Run one F1b arm per Tier-1 task and compare it directly against W0 control, W0 support+context, and F1a.
4. Use the result to decide between reopening W2, opening F2 GRPO-lite, or stopping after F1b.

## Concrete Steps
1. Extend `WriterWeaverHead` with writer-local micro-LoRA support on conditioning and encoder projection layers.
2. Plumb writer-adapter config, trainability control, checkpoint metadata, and gradient logging through `m4_shared_injection.py`.
3. Add F1b config templates for GSM8K, NarrativeQA, and FEVER-label-gen with:
   - the same larger F1a writer shape,
   - tiny writer-only adapters,
   - `pilot_trainable_variant=writer_adapter_only`.
4. Add an F1b runner that:
   - reuses W0 and F1a review artifacts,
   - runs one adapter-only arm per Tier-1 task,
   - publishes a structured review bundle.
5. Add an F1b summary script and regression test for the phase gate.

## Validation & Acceptance
- Writer micro-LoRA wiring passes targeted unit tests.
- F1b runner completes on all Tier-1 tasks and publishes review artifacts.
- The F1b summary reports exactly one of:
  - `move_to_w2`
  - `move_to_f2`
  - `stop_after_f1b`
- No receiver-side adapter path is enabled.

## Progress
- 2026-03-09: Created from `PLANv4.md` fallback F1 after F1a resolved to `move_to_f1b`.

## Decision Log
- Keep the larger F1a writer shape fixed so F1b measures adapter effect, not another architecture change.
- Freeze the base writer during F1b and train only the writer-side micro-LoRA plus the projector.
- Target only addressable writer projection layers; do not reopen the receiver micro-LoRA stack.

## Surprises & Discoveries
- None yet.
