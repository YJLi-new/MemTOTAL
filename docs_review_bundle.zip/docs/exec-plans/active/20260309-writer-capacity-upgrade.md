# 20260309 Writer Capacity Upgrade

## Purpose
Execute `PLANv4.md` fallback F1a after W0 finished as `plumbing_only`: increase WriterWeaver capacity before reopening any receiver-side idea, and test whether extra conditioning depth plus a less bottlenecked writer can finally move usefulness.

## Context
- Macro authority remains `PLAN.md`.
- Narrow authority is `PLANv4.md` Section 18.1 fallback F1.
- W0 already proved the writer-direct scaffold is real, published, and reproducible.
- W0 did not authorize W1/W2: `comparison_conclusion=plumbing_only`, `move_to_w1=false`, `stop_after_w0=true`.
- The likely remaining problem is not wiring but Writer capacity: W0 support+context changed geometry, yet `common_mode_energy_ratio` stayed pinned near `1.0` and non-FEVER `delta_answer_logprob` stayed `0.0`.

## Plan of Work
1. Increase WriterWeaver conditioning capacity without changing the frozen reasoner contract.
2. Keep the same direct-bridge losses and the same small Tier-1 slices used by W0.
3. Compare the new bigger-writer arm directly against the published W0 support+context baseline and W0 control.
4. Use the result to decide between opening W2 or moving deeper into fallback F1b.

## Concrete Steps
1. Extend `WriterWeaverHead` so it can stack multiple context/support conditioning passes.
2. Plumb the new writer-capacity knob through `m4_shared_injection.py` metadata and checkpoint payloads.
3. Add F1a config templates for GSM8K, NarrativeQA, and FEVER-label-gen with:
   - same latent token budget,
   - larger feed-forward hidden size,
   - deeper writer encoder,
   - deeper conditioning stack.
4. Add an F1a runner that:
   - reuses W0 review datasets and reference metrics,
   - runs one bigger support+context arm per Tier-1 task,
   - publishes a structured review bundle.
5. Add an F1a summary script and a unit test for its gate logic.

## Validation & Acceptance
- New writer-capacity code passes targeted unit tests.
- The F1a runner completes on all Tier-1 tasks and publishes review artifacts.
- The F1a summary reports one of:
  - `move_to_w2`
  - `move_to_f1b`
- No receiver-side PEFT is reintroduced.

## Progress
- 2026-03-09: Created from `PLANv4.md` fallback F1 after W0 stopped at `plumbing_only`.

## Decision Log
- Keep the frozen reasoner, injector, and usefulness losses unchanged.
- Reuse W0 control and support+context review artifacts as the explicit reference family.
- Keep the latent token budget fixed; increase writer capacity through depth and hidden width instead of more injected tokens.

## Surprises & Discoveries
- pending
